# bagisto-lang-zh

#### 使用说明

1. 配置.env

```ini
APP_LOCALE=zh
```

2. 不建议设置为 zh-CN 或者 zh_CN
