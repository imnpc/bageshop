<?php

return [
    'slug' => ':attribute 无效',
    'code' => ':attribute 无效',
    'decimal' => ':attribute 无效'
];
