<?php

return [
    'enter-attribute' => '请输入 :attribute',
    'select-attribute' => '请选择 :attribute'
];
